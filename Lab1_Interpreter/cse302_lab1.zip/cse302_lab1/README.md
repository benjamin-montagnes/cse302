BX0 Interpreter
---------------

scanner.py         : lexical scanner
parser.py          : parser
bx0_interpreter.py : (dummy) interpreter

Scan the Python files for the string 'TODO' and then complete the
tasks indicated therein.

For details about the BX0 language, see the lab handout.
